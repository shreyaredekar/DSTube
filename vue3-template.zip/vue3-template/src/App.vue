<template>
    <div id="app">
        <Header :visited="visited" />
    <router-view :visited="visited" />
    <Footer />
    </div>
</template>
  
<script setup>

import { ref } from 'vue';
import Header from "./components/Home/Header.vue";
import Footer from "./components/Home/Footer.vue";

const visited = ref(0); // Define the visited count in the parent component

// You can handle the incrementing logic here based on your application flow
// For example, if you have multiple cards, you might want to handle the click event here and pass down the updated count to the Header component

// Function to increment the visited count
const incrementVisited = () => {
  visited.value++;
};
</script>
  
<style>

@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap');

body {
    margin: 0px;
    height: 100vh;
    font-family: 'Roboto', sans-serif;
}

#app {
    height: 100%;
}

.main-container {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}
</style>
  