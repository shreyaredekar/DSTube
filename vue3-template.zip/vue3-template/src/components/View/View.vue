<template>
  <div class="page">
    <div class="container">
      <div class="video-card">
        <div class="video-thumbnail">
          <img :src="video.imageUrl" :alt="'Card Image ' + video.id" class="thumbnail-image">
        </div>
        <div class="video-details">
          <h3 class="video-title">{{ video.title }}</h3>
          <p class="video-views">Views: {{ video.views }}</p>
          <div class="channel-info">
            <img :src="video.channelImgSrc" :alt="'Channel Image ' + video.id" class="channel-image">
            <div class="channel-details">
                <p class="channel-name">Tom & Jerry Official</p>
            </div>
            <div class="channel-subscribe">
              <p class="channel-name">{{ video.creator.firstname }}  {{ video.creator.lastname }}</p>
              <button @click="toggleSubscription" class="subscribe-button" :class="{ 'subscribed': isSubscribed }">
                {{ isSubscribed ? 'Subscribed' : 'Subscribe' }}
              </button>
            </div>
          </div>
          <div class="video-actions">
            <button @click="likeVideo" class="action-button like-button">
              Like {{ likes }}
            </button>
            <button @click="dislikeVideo" class="action-button dislike-button">
              Dislike
            </button>
            <button class="action-button share-button">Share</button>
            <p class="video-status" :class="[getStatusClass]">{{ getStatus }}</p>
          </div>
        </div>
        <input
      type="text"
      placeholder="Enter your comment"
      v-model="comment"
      class="comment-input"
    />
    
    <button @click="submitComment" class="submit-button">Submit</button>

    
    <div v-if="comments.length > 0" class="comments-section">
      <h4>Comments:</h4>
      <ul>
        <li v-for="(comment, index) in comments" :key="index" class="comment-item">
          {{ comment }}
        </li>
      </ul>
    </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, reactive, onMounted } from "vue";
import {useRoute} from 'vue-router';
import data from '../../assets/config/data.json';



const video = reactive({
  imgSrc: '',
  title: '',
  views: 0,
  channelImgSrc: '',
  creator: {
    firstname: '',
    lastname: ''
  }
});

const likes = ref(0);
const comment = ref("");
const isSubscribed = ref(false);
const comments = ref([]);

const likeVideo = () => {
  likes.value++;
};

const dislikeVideo = () => {
  if (likes.value > 0) {
    likes.value--;
  }
};

const toggleSubscription = () => {
  isSubscribed.value = !isSubscribed.value;
};


const submitComment = () => {
  if (comment.value.trim() !== "") {
    // Add the comment to the comments array
    comments.value.push(comment.value);
    // Clear the input field after submitting the comment
    comment.value = "";
  } else {
    console.error("Comment cannot be empty");
  }
};

const route = useRoute();

onMounted(() => {
  const id = route.params.id;
  const fetchedVideo = data.find(item => item.id === id);
  Object.assign(video, fetchedVideo);

  // const count=ref(useVisitedStore().count);
});

const getStatus = computed(() => {
  if (likes.value > 15) {
    return 'Popular';
  } else if (likes.value > 10) {
    return 'Trending';
  } else {
    return '';
  }
});

const getStatusClass = computed(() => {
  return getStatus.value.toLowerCase();
});

</script>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-color: #f9f9f9;
  font-family: Arial, sans-serif;
}

.container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-grow: 1;
  margin-bottom: 80px;
}

.video-card {
  border-radius: 8px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.2);
  padding: 20px;
  width: 70%;
  max-width: 800px;
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  background-color: #fff;
}

.video-thumbnail {
  width: 100%;
  height: auto;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  overflow: hidden;
  border: none;
}
.thumbnail-image {
  width: 100%;
  height: auto;
  object-fit: cover;
}

.video-details {
  padding: 20px;
}

.video-title {
  font-size: 24px;
  margin-bottom: 10px;
  color: #333;
}

.video-actions {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  margin-top: 15px;
}

.action-button {
  padding: 8px 16px;
  margin-right: 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  color: #050505;
  font-weight: 500;
  background-color: transparent;
  transition: color 0.3s ease, background-color 0.3s ease;
}

.action-button:hover {
  color: #fdfdfd;
  background-color: #606060;
}

.like-button {
  background-color: #e76d08;
}

.dislike-button {
  background-color: #96bee2;
}

.share-button {
  background-color: #28c222;
}

.channel-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 15px;
}

.channel-details {
  display: flex;
  flex: 1;
  align-items: center;
}

.channel-subscribe {
  display: flex;
  align-items: center;
  justify-content: flex-start; /* Align items to the left end */
}

.subscribe-button {
  padding: 8px 16px;
  background-color: #cc0000;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.channel-name {
  font-size: 16px;
  margin-left: 10px;
  color: #606060;
}

.subscribe-button:hover {
  background-color: #990000;
}

.comment-input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-bottom: 10px;
  font-size: 14px;
}

.submit-button {
  width: 100%;
  padding: 10px;
  background-color: #cc0000;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  font-size: 16px;
}

.submit-button:hover {
  background-color: #990000;
}

.comments-section {
  margin-top: 20px;
}

.comment-item {
  margin-bottom: 10px;
  list-style-type: none; /* Remove default bullet points */
  position: relative; /* Make the container relative to position the arrow */
}

.comment-item::before {
  content: "\27A4"; /* Set the content to be an arrow */
  position: absolute; /* Position the arrow */
  left: -20px; /* Adjust the left position */
  top: 50%; /* Center the arrow vertically */
  transform: translateY(-50%); /* Center the arrow vertically */
  color: #999; /* Color of the arrow */
  font-size: 14px; /* Size of the arrow */
}

.channel-image {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
}

.video-status {
  margin-bottom: 10px;
  font-weight: bold;
  text-transform: uppercase;
}

.popular {
  background-color: #03b2f7;
  padding: 2px 6px;
  width: 82px;
}

.trending {
  background-color: #ffd700;
  padding: 2px 6px;
  width: 87px;
}
</style>
