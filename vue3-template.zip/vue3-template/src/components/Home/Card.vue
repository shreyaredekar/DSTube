<template>
  <div>
    <div v-for="index in videolist" :key="index.id" class="card-wrapper" @click="handleCardClick(index)">
     <router-link :to="'/view/' + index.id" class="card-link">
       <div class="card">
         <img :src="index.imageUrl" :alt="'Card Image ' + index" class="card-image">
         <div class="card-details">
           <h3 class="card-title">{{ index.title }}</h3>
           <p class="card-views">{{ index.views }}</p>
           <p class="card-info">{{ index.description }}</p>
         </div>
       </div>
     </router-link>
   </div>
 </div>

   
   <div v-if="selectedCard" class="modal">
     <div class="modal-content">
       <span class="close" @click="closeModal">&times;</span>
       <img :src="selectedCard.imageUrl" alt="Card Image" class="modal-image">
       <div class="modal-details">
         <h2 class="modal-title">{{ selectedCard.title }}</h2>
         <p class="modal-views">{{ selectedCard.views }}</p>
         <p class="modal-info">{{ selectedCard.description }}</p>
         <button @click="like">Like</button>
         <button @click="showCommentForm">Comment</button>
         <button @click="share">Share</button>
       </div>
     </div>
   </div>

   
   <div v-if="showComment" class="comment-modal">
     <textarea v-model="commentText" rows="4" cols="50"></textarea>
     <button @click="saveComment">Save</button>
   </div>
 </template>
 
 <script setup>
 import {ref} from 'vue';
 import Data from '../../assets/config/data.json'
 const videolist= ref(Data);

//  const handleCardClick = (index) => {
//   // Increment visited count
//   visited.value++;
//   selectedCard.value = index;
//   // You can optionally perform any other actions related to the card click here
// };
 </script>
 
 <style scoped>
 .card-wrapper {
 margin-bottom: 20px;
}

.card {
 display: flex;
 border-radius: 8px;
 overflow: hidden;
 transition: box-shadow 0.3s ease-in-out;
 background-color: #ffffff;
 box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.card:hover {
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

.card-image {
  width: 300px;
  height: auto;
  border-top-left-radius: 8px;
  border-bottom-left-radius: 8px;
  transition: transform 0.3s ease-in-out;
}

.card:hover .card-image {
   transform: scale(1.05);
 }

/* .card-image {
 width: 200px;
 height: auto;
 border-top-left-radius: 8px;
 border-bottom-left-radius: 8px;
 
} */

.card-details {
 flex: 1;
 padding: 20px;
}

.card-title {
 font-size: 20px;
 font-weight: bold;
 margin-bottom: 10px;
 color: rgb(3, 3, 3);
}

.card-views {
 font-size: 14px;
 color: black;
 margin-bottom: 5px;
}

.card-info {
 font-size: 14px;
 margin-bottom: 5px;
 color: rgb(3, 3, 3);
}

.card-link {
 text-decoration: none;
}
 
</style>
 