<template>
    <footer>
      <p>&copy; 2024 Dassault Systemes</p>
    </footer>
  </template>
  
  <script>
  
  </script>
  
  <style scoped>
  footer {
    background-color: #333;
    color: white;
    padding: 10px;
    text-align: center;
  }
  </style>
  