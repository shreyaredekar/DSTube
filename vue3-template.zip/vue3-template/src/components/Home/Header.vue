<template>
  <header>
    <div class="header-container">
      <router-link to="/" class="button">DsTube</router-link>
      <div class="visited">
        Visited: {{ visited }}
      </div>
      <div class="search-bar">
        <input type="text" v-model="searchTerm" @input="filterCards" placeholder="Search" class="search-input" />
        <button @click="search" class="button">Search</button>
      </div>
      <router-link to="/profile" class="button">Profile</router-link>
    </div>
  </header> 
</template>
  
<script setup>

import { ref } from 'vue';
import Data from '../../assets/config/data.json';


const videolist = ref(Data);
const searchTerm = ref('');
const visited = ref(0);

const filterCards = () => {
  // Filter the cards based on the search term
  const filteredCards = Data.filter(card => card.title.toLowerCase().includes(searchTerm.value.toLowerCase()));
  console.log(filteredCards); // Add this line
  videolist.value = filteredCards;
}

const handleCardClick = () => {
  // Increment visited count when a card is clicked
  visited.value++;
}
</script>

<style>
header {
    background-color: black;
    color: white;
    padding: 10px;
  }
  
  .header-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 50px;
  }
  
  .button {
    background-color: red;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-decoration: none;
  }
  
  button:hover {
    background-color: #45a049;
  }

  .search-bar {
    display: flex;
    align-items: center;
  }
  
  input[type="text"] {
    padding: 5px;
    border: 1px solid rgb(61, 61, 61);
    margin-right: 5px;
    background-color: rgb(255, 255, 255);
    width: 500px;
  }

  .home-button {
    background-color: red;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-decoration: none;
}
  
.button:hover {
    background-color: #45a049;
}

</style>