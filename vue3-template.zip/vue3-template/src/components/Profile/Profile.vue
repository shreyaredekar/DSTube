<template>
    <div class="page">
      <Header/>
      <div class="container">
        <div class="profile-form" >
          <h2 id="title" class="title">Profile Information</h2>
          <form class="form-container">
            <div class="form-group">
              <label for="name">Name:</label>
              <input type="text" id="text" v-model="formData.name" required>
            </div>
            <div class="form-group">
              <label for="email">Email:</label>
              <input type="email" id="email" v-model="formData.email" required>
            </div>
            <div class="form-group">
              <label for="phone">Phone:</label>
              <input type="tel" id="phone" v-model="formData.phone" required>
            </div>
            <div class="form-group">
              <label for="password">Password:</label>
              <input type="password" id="password" v-model="formData.password" required>
            </div>
            <div class="button-group">
              <button type="submit" class="save-button">Save</button>
            </div>
          </form>
        </div>
      </div>
      <div class="container container-2">
        <div class="profile-details-container">
          <div class="profile-details">
            <h2>Profile Details</h2>
            <div class="details">
              <p><strong>Name:</strong> {{ formData.name }}</p>
              <p><strong>Email:</strong> {{ formData.email }}</p>
              <p><strong>Phone:</strong> {{ formData.phone }}</p>
            </div>
          </div>
        </div>
      </div>
      <Footer/>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  
  const formData = ref({
    name: '',
    email: '',
    phone: '',
    password: ''
  });
  
  let isEditMode = ref(false);
  
  const saveOrUpdateProfile = () => {
    if (isEditMode.value) {
      console.log('Updated Profile Data:', formData.value);
      isEditMode.value = false;
    } else {
      console.log('Saved Profile Data:', formData.value);
      clearFormData();
    }
  };
  
  const clearFormData = () => {
    formData.value.name = '';
    formData.value.email = '';
    formData.value.phone = '';
    formData.value.password = '';
  };
  </script>
  
  <style scoped>
  
  .page {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    background-color: #f8f9fa; 
    font-family: Arial, sans-serif;
    color: #333;
    background-image: linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.3)),url("https://www.pixelstalk.net/wp-content/uploads/2016/05/Youtube-HD-Wallpapers-Free-Download-620x349.png");
    background-size: cover;
    background-position: center;
  }

  
  .Header,
  .Footer {
    background-color: #007bff; 
    color: #fff; 
    padding: 10px;
    text-align: center;
  }

  
  .container {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-grow: 1;
    margin-top: 100px; 
  }

  .profile-form {
    background: transparent;
    backdrop-filter: blur(3px);
    border: 1px solid #fff;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
    padding: 20px;
    width: 80%;
    max-width: 500px;
    color: #fff;
  }

  .form-container {
    margin-top: 20px;
  }

  label {
    font-weight: bold;
    margin: 10px 5px;
  }

  input {
    width: 95%;
    padding: 10px;
    border: 1px solid #e0d4d4;
    border-radius: 5px;
    transition: border-color 0.3s ease;
    margin: 5px 5px;
  }

  input[type="text"] {
    width: 95%;
    padding: 10px;
    border: 1px solid #e0d4d4;
    border-radius: 5px;
    transition: border-color 0.3s ease;
    margin: 5px 5px;
  }

  input:focus {
    border-color: #007bff; 
  }

  .button-group {
    margin-top: 20px;
    display: flex;
    justify-content: flex-end;
  }

  .save-button,
  .update-button {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    background-color: #007bff; 
    color: #fff;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  .save-button:hover,
  .update-button:hover {
    background-color: #0056b3; 
  }

 
  .container-2 {
    margin-top: 20px;
    margin-bottom: 50px; 
  }

  .profile-details-container {
    background: transparent;
    backdrop-filter: blur(3px);
    border: 1px solid #fff; 
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Soft shadow */
    padding: 20px;
    width: 80%;
    max-width: 500px;
    color: #fff;
  }

  .profile-details {
    padding-top: 20px;
  }

  .details p {
    margin-bottom: 10px;
  }
</style>
  