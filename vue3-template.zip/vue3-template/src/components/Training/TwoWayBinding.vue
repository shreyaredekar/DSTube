<template>
    <div>
        <input type = "text" v-model ="name"/>
        <p>{{ name }}</p>
    </div>
</template>

<script setup>
import {ref} from "vue"

 let name = ref("andrew")

</script>