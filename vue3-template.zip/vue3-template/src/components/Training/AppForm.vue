<template>
    <h1>Form Component</h1>
    <!-- <div>
        <h1>Some header</h1>
        <p>Details</p>
    </div> -->
    <slot>
        
    </slot>
</template>
