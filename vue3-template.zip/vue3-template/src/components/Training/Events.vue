<template>
    <div>
        <button @click="$emit('someEvents')">Add</button>
    </div>
</template>

<script setup>

// const someEvents = () => {
//     console.log("some events")
// }
</script>