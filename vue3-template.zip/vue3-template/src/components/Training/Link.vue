<template>
    <div>
        <a v-bind:href="link">Home</a>
    </div>
</template>

<script setup>
import {ref} from "vue";

let link = ref("https://www.google.com/")
</script>