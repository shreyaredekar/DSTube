<template>
    <h1>Counter</h1>
    <!-- <p> {{ state.count }}</p>
    <p> {{ counter }}</p> -->
    <button @click="increment()">Click here</button>
</template>

<script setup>
import { reactive, ref } from 'vue';

const state = reactive ({ count: 0 });
const counter = ref(10);
const increment = () => {
    console.log("Count Incremented");
    state.count++;
    counter.value++;
}

</script>

<style scoped>
h1{
    color: blue;
}
.my-button {
        background-color: #4caf50;
        border: none;
        color: white;
        padding: 8px 16px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 14px;
        border-radius: 4px;
        cursor: pointer;
}
</style>