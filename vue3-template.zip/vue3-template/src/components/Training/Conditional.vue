<template>
    <div>
        <p> Hello Luke</p>
        <h2 v-if = "flag">Good Morning</h2>
        <h2 v-else>Good Bye</h2>

        <button @click="onClick">Click</button>
        <P v-show="flag">Clicked</P>
    </div>
</template>

<script setup>
import { ref } from 'vue';
let flag = ref(true)

const onClick = () => {
    flag.value = !flag.value
}
</script>