<template>
    <div>
        <p>
            Count :: {{ count }}
        </p>
        <button v-on:click="counter">increment</button>
        <button v-on:dblclick.once="counter">add</button>
    </div>
</template>

<script setup>
import {ref} from 'vue';
let count = ref(0)

const counter = () => {
    count.value++
    console.log("clicked")
}

</script>