<template>
    <h1>Counter</h1>
    <p> {{ state.count }}</p>
    <p> {{ counter }}</p>
    <button @click="increment()">Click here</button>
</template>

<script setup>
import { reactive, ref } from 'vue';

const state = reactive ({ count: 0 });
const counter = ref(10);
const increment = () => {
    console.log("Count Incremented");
    state.count++;
    counter.value++;
}

</script>

<style></style>