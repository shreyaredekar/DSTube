<template>
    <div>
        <ul>
            <li v-for="item in data" :key="item.id">{{ item.value }}</li>
        </ul>
    </div>
</template>

<script setup>
import {ref} from 'vue';

const data = ref([
{id:1, value:"apple"},
{id:2, value:"banana"}, 
{id:3, value:"watermelon"}, 
{id:4, value:"mango"}, 
{id:5, value:"papaya"}])
</script>