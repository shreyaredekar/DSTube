<template>
    <h1>Template</h1>
    <p> {{ "Javascript Code" }}</p>
    <p> {{ 4+3 }}</p>
    <p> {{ true? 'Yes' : 'No' }}</p>
    <p> {{ getTodaysDate() }}</p>
</template>

<script setup>

const getTodaysDate = () => {

    return new Date ().toDateString();
}
</script>

<style></style>