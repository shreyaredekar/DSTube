<template>
    <div>
        <p>
            Hello vue
            <span v-html = "span_tag">

            </span>
        </p>
    </div>
</template>

<script setup>
import {ref} from 'vue';

let span_tag = ref('<span>This span tag</span>')
</script>