<template>
    <h1>Primary Button Component</h1>
</template>

<script setup>
import { onBeforeMount, onMounted } from 'vue';

onBeforeMount(()=>{
    console.log("onBefore mounted in Primary Button");
});
onMounted(()=>{
    console.log("the component is mounted");
});
</script>