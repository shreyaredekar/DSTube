// router.js

import { createRouter, createWebHistory } from 'vue-router';
import Profile from './components/Profile/Profile.vue';
import Home from './components/Home/Home.vue';
import View from './components/View/View.vue';


const routes = [
  {
    path: '/profile',
    name: 'Profile',
    component: Profile
  },
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/view/:id',
    name: 'View',
    component: View
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
